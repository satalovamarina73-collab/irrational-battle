import json
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "10000"))
BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "leaderboard.json")
scores = []

def load_scores():
    global scores
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data=json.load(f)
            if isinstance(data,list):
                scores=data
    except Exception:
        scores=[]
load_scores()

def save_scores():
    try:
        with open(DATA_FILE,"w",encoding="utf-8") as f:
            json.dump(scores,f,ensure_ascii=False,indent=2)
    except Exception:
        pass

def clean_name(name):
    name=re.sub(r"[\x00-\x1f\x7f]","",str(name or "").strip())
    return name[:18]

class Handler(BaseHTTPRequestHandler):
    def json(self, code, obj):
        raw=json.dumps(obj,ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin","*")
        self.send_header("Access-Control-Allow-Headers","Content-Type")
        self.send_header("Access-Control-Allow-Methods","GET,POST,OPTIONS")
        self.send_header("Content-Length",str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.json(204,{})

    def do_GET(self):
        path=urlparse(self.path).path
        if path=="/api/health":
            self.json(200,{"ok":True,"server":"IRRATIONAL"})
            return
        if path=="/api/leaderboard":
            ordered=sorted(scores,key=lambda x:(-int(x.get("score",0)),-int(x.get("level",1))))
            self.json(200,{"ok":True,"entries":ordered[:100]})
            return
        if path in ("/","/index.html"):
            try:
                with open(os.path.join(BASE,"index.html"),"rb") as f: raw=f.read()
                self.send_response(200)
                self.send_header("Content-Type","text/html; charset=utf-8")
                self.send_header("Content-Length",str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            except Exception:
                self.json(500,{"ok":False,"error":"index.html not found"})
            return
        self.json(404,{"ok":False,"error":"not found"})

    def do_POST(self):
        global scores
        if urlparse(self.path).path!="/api/score":
            self.json(404,{"ok":False,"error":"not found"})
            return
        try:
            n=int(self.headers.get("Content-Length","0"))
            if n>10000: raise ValueError()
            p=json.loads(self.rfile.read(n).decode())
            pid=str(p.get("player_id","")).strip()
            name=clean_name(p.get("player_name",""))
            score=int(p.get("score",0)); level=int(p.get("level",1))
        except Exception:
            self.json(400,{"ok":False,"error":"invalid data"}); return
        if not (5<=len(pid)<=100 and 2<=len(name)<=18 and 0<=score<=100000000 and 1<=level<=999):
            self.json(400,{"ok":False,"error":"invalid data"}); return
        found=next((x for x in scores if x.get("player_id")==pid),None)
        if found:
            found["player_name"]=name
            found["score"]=max(int(found.get("score",0)),score)
            found["level"]=max(int(found.get("level",1)),level)
        else:
            scores.append({"player_id":pid,"player_name":name,"score":score,"level":level})
        scores=sorted(scores,key=lambda x:(-int(x.get("score",0)),-int(x.get("level",1))))[:100]
        save_scores()
        rank=next((i+1 for i,x in enumerate(scores) if x.get("player_id")==pid),None)
        self.json(200,{"ok":True,"rank":rank,"entries":scores})

print("IRRATIONAL server starting on port",PORT)
ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
